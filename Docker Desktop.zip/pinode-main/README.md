# pinode
node operating
